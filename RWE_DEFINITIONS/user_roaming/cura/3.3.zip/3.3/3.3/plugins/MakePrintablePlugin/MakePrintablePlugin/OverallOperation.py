from UM.Operations.Operation import Operation
from UM.Signal import Signal
from UM.Logger import Logger
from .UploadNodes import UploadNodes
from .FixNodes import FixNodes
from .DownloadNodes import DownloadNodes
from . import Global
import sys
import time
import threading


class OverallOperation(Operation):
    def __init__(self, nodes, quality=None, post_opt=None, clearance=None, thickness=None, close_holes=None, user_group=None):
        super().__init__()
        if user_group is None:
            user_group = "Free"
        self.progress = Signal()
        self._progress_emit_time = None
        self._progress = 0
        self._nodes = nodes
        self._oldnodes = nodes
        self._quality = quality
        self._post_opt = post_opt
        self._clearance = clearance
        self._thickness = thickness
        self._close_holes = close_holes
        self._user_group = user_group

    def process(self):
        funcs = [self.upload, self.fix, self.download]
        i = 7 * len(self._nodes)
        for func in funcs:
            try:
                if func == self.upload:
                    Global.progress_bar = 0
                    Global.message = "Uploading to MakePrintable.com"
                elif func == self.fix:
                    Global.progress_bar = 0
                    Global.message = "Fixing in MakePrintable.com"
                else:
                    Global.progress_bar = -1
                    Global.message = "Downloading from MakePrintable.com"
                func()
            except Exception as e:
                Global.fixed = dict.fromkeys(Global.fixed, False)
                Global.failed_reason = dict.fromkeys(Global.failed_reason, 'an exception occurred')
                line = sys.exc_info()[2].tb_lineno
                Logger.log('e', '[Makeprintable] Exception: {} line: {} in OverallOperation.py'.format(str(e), line))
                self._nodes.clear()
            # if len(self._nodes) == 0:
            #     self._emit_progress(i)
                return
            i -= 2 * len(self._nodes)
            if func == self.fix:
                i -= len(self._nodes)

    def upload(self):
        try:
            Logger.log('i', '[Makeprintable] Now uploading started')
            up = UploadNodes(self._nodes)
            up.progress.connect(self._send_progress)
            thread = MPThread(up)
            thread.start()
            thread.join()
            self._send_progress(95)
            succ = up.get_len_success()
            self.onFailure(succ)
            Logger.log('i', '[Makeprintable] Now uploading finished')
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in OverallOperation.py'.format(str(e), line))
            raise e

    def fix(self):
        try:
            Logger.log('i', '[Makeprintabe] Now fixing started')
            fx = FixNodes(self._nodes, self._quality, self._post_opt, self._clearance, self._thickness, self._close_holes, self._user_group)
            fx.progress.connect(self._send_progress)
            thread = MPThread(fx)
            thread.start()
            thread.join()
            succ = fx.get_len_success()
            self.onFailure(succ)
            Logger.log('i', '[Makeprintable] Now fixing finished')
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in OverallOperation.py'.format(str(e), line))
            raise e

    def download(self):
        try:
            Logger.log('i', '[Makeprintable] Now downloading started')
            self._emit_progress(1)
            dw = DownloadNodes(self._nodes)
            dw.process()
            Global.message = "Finished"
            Logger.log('i', '[Makeprintable] Now downloading finished')
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in OverallOperation.py'.format(str(e), line))
            raise e

    def onFailure(self, succ):
        if succ == 0:
            Global.fixed = dict.fromkeys(Global.fixed, False)
            self._nodes.clear()
        else:
            for node in self._nodes:
                if Global.fixed[node] is False:
                    self._nodes.remove(node)

    def _send_progress(self, iterations):
        Global.progress_bar += iterations
        self._emit_progress(iterations)

    def _emit_progress(self, progress):
        self._progress += progress
        self.progress.emit(self._progress)
        self._progress = 0
        # new_time = time.monotonic()
        # if not self._progress_emit_time or new_time - self._progress_emit_time > 0.5:
        #     self.progress.emit(self._progress)
        #     self._progress_emit_time = new_time
        #     self._progress = 0

    def undo(self):
        self._nodes = self._oldnodes

    def redo(self):
        pass

    def mergeWith(self, other):
        if type(other) is not OverallOperation:
            return False

        if other._nodes != self._nodes:
            return False

        op = OverallOperation(self._nodes)
        op._old_model = other._old_model
        return op

    def __repr__(self):
        return "OverallOperation(nodes = {0})".format(self._nodes)


class MPThread(threading.Thread):
    def __init__(self, operation, callback=None):
        threading.Thread.__init__(self)
        self._operation = operation
        self._callback = callback

    def run(self):
        self._operation.process()
        if self._callback:
            self._callback()

    def stop(self):
        self._stop().set()
