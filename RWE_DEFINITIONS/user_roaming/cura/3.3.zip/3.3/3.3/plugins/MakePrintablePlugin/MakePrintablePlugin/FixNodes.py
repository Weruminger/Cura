from UM.Operations.Operation import Operation
from UM.Signal import Signal
from UM.Logger import Logger
from .RequestHandler import RequestHandler
from . import Global
import tempfile
import os
import sys
import time
import threading


class FixNodes(Operation):
    def __init__(self, nodes, model_quality=None, post_opt=None, clearance=None,
                 thickness=None, close_holes=None, user_group=None):
        super().__init__()
        if model_quality is None:
            model_quality = 1
        if post_opt is None:
            post_opt = 100
        if clearance is None:
            clearance = 0
        if thickness is None:
            thickness = 0
        if close_holes is None:
            close_holes = 250
        if user_group is None:
            user_group = "Free"
        self._iterations = 0
        self._total_iterations = 0
        self.progress = Signal()
        self._progress_emit_time = None
        self._progress = 0
        self._nodes = nodes
        self._tempdir = tempfile.gettempdir()
        self._tempdir.replace('\\', '/')
        model_quality_str = None
        self._success = 0
        if model_quality == 1:
            model_quality_str = "standard"
        elif model_quality == 2:
            model_quality_str = "high"
        self._user_group = user_group
        self._fixer_settings = None
        # if user_group == "Free":
        #     self._fixer_settings = "{\"print_quality\": \"" + model_quality_str + "\", \"post_optimize\": " + str(post_opt) + ", \"hollow\": 0, \"wall_thickness\": " + str(thickness) + ", \"texture\": false, \"scale_x\": 1, \"scale_y\": 1, \"scale_z\": 1, \"transform_x\": 0, \"transform_y\": 0, \"transform_z\": 0, \"rotate_x\": 0, \"rotate_y\": 0, \"rotate_z\": 0}"
        # else:
        self._fixer_settings = "{\"print_quality\": \"" + model_quality_str + "\",\"post_optimize\": " + str(post_opt) + ",\"hollow\": 0,\"wall_thickness\":" + str(thickness) + ",\"texture\":false, \"scale_x\":1, \"scale_y\":1, \"scale_z\":1,\"transform_x\":0,\"transform_y\":0,\"transform_z\":0,\"rotate_x\":0,\"rotate_y\":0,\"rotate_z\":0,\"clearance\":" + str(clearance) + ", \"closing_threshold\":" + str(close_holes) + "}"

    def process(self):
        item_ids = []
        success = {}
        failed = {}
        try:
            for node in self._nodes:
                if Global.fixed[node]:
                    filename = node.getMeshData().getFileName()
                    item_ids.append(Global.file_item_id[filename])
            requesthandler = RequestHandler()
            requesthandler.progress.connect(self._send_progress)
            access_token = Global.access_token
            Logger.log('i', '[Makeprintable] Number of nodes to fix: ' + str(len(item_ids)))
            if len(item_ids) > 0:
                thread = MPThread(requesthandler.fix, args=(access_token, item_ids, self._fixer_settings, self._user_group))
                thread.start()
                thread.join()
                result = thread.get_result()
                success, failed = result[0], result[1]
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintabe] Exception: {} line: {} in FixNodes.py'.format(str(e), line))
            raise e
        finally:
            for node in self._nodes:
                filename = node.getMeshData().getFileName()
                base = os.path.splitext(os.path.basename(filename))[0]
                base = Global.get_valid_string(base)
                if base not in success:
                    Global.fixed[node] = False
                    Global.failed_reason[node] = failed[base] if base in failed else 'You have maxed out your balance or fix failed'
                else:
                    Global.download_link[node] = success[base]
            self._success = len(success)

    def get_len_success(self):
        return self._success

    def _emit_progress(self, progress):
        self._progress += progress
        self.progress.emit(self._progress)
        self._progress = 0
        # new_time = time.monotonic()
        # if not self._progress_emit_time or new_time - self._progress_emit_time > 0.5:
        #     self.progress.emit(self._progress)
        #     self._progress_emit_time = new_time
        #     self._progress = 0

    def _send_progress(self, iterations):
        self._emit_progress(iterations)

    def undo(self):
        pass

    def redo(self):
        pass

    def mergeWith(self, other):
        if type(other) is not FixNodes:
            return False
        if other._nodes != self._nodes:
            return False
        op = FixNodes(self._nodes)
        return op

    def __repr__(self):
        return "FixNodes(nodes = {0})".format(self._nodes)


class MPThread(threading.Thread):
    def __init__(self, func, args=()):
        threading.Thread.__init__(self)
        self._func = func
        self._args = args
        self._result = None

    def run(self):
        self._result = self._func(*self._args)

    def get_result(self):
        return self._result

    def stop(self):
        self._stop().set()
