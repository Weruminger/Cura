from UM.Logger import Logger
from .RequestHandler import RequestHandler
from . import Global
import tempfile
import zipfile
import sys
import os


class DownloadNodes:
    def __init__(self, nodes):
        self._nodes = nodes
        self._tempdir = tempfile.gettempdir()

    def process(self):
        try:
            access_token = Global.access_token
            for node in self._nodes:
                filename = node.getMeshData().getFileName()
                if Global.fixed[node]:
                    download_link = Global.download_link[node]
                    res = RequestHandler.download(download_link, self._tempdir + '/mp_cura_exported_model.zip')
                    with zipfile.ZipFile(self._tempdir + '/mp_cura_exported_model.zip') as file:
                        file.extractall(self._tempdir)
                    Global.downloaded[filename] = True
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in DownloadNodes.py'.format(str(e), line))
            for node in self._nodes:
                filename = node.getMeshData().getFileName()
                base = os.path.splitext(os.path.basename(filename))[0]
                base = Global.get_valid_string(base)
                if filename not in Global.downloaded:
                    Global.fixed[node] = False
                    Global.failed_reason[node] = "Could not download model."
