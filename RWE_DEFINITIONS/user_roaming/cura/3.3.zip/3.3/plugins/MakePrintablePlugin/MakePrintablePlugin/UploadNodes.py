from UM.Operations.Operation import Operation
from UM.Signal import Signal
from UM.Logger import Logger
from UM.Application import Application
from .RequestHandler import RequestHandler
from . import Global
import tempfile
import os
import sys
import random
import time
import threading


class UploadNodes(Operation):
    def __init__(self, nodes):
        super().__init__()
        self._nodes = nodes
        self._tempdir = tempfile.gettempdir()
        self._tempdir.replace('\\', '/')
        self.progress = Signal()
        self._progress_emit_time = None
        self._progress = 0
        self._success = 0

    def export_file(self, scenenode):
        writer = Application.getInstance().getMeshFileHandler().getWriter("STLWriter")
        nodes = []
        nodes.append(scenenode)
        filename = scenenode.getMeshData().getFileName()
        basename = os.path.splitext(os.path.basename(filename))[0]
        basename = Global.get_valid_string(basename)
        randbits = random.getrandbits(32)
        new_filename = "{}/{}{}.stl".format(self._tempdir, basename, randbits)
        try:
            with open(new_filename, 'wb') as stream:
                writer.write(stream, nodes, mode=writer.OutputMode.BinaryMode)
            fixed_name = "{}/{}{}_fixed.obj".format(self._tempdir, basename, randbits)
            return new_filename, fixed_name
        except IOError as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in UploadNodes.py'.format(str(e), line))
            raise e

    def export_all_files(self):
        Logger.log('i', '[Makeprintable] Now exporting started')
        filenames = []
        try:
            for node in self._nodes:
                filename, fixed_name = self.export_file(node)
                node.setMeshData(node.getMeshData().set(file_name=filename))
                filenames.append(filename)
                Global.fixed_filenames[node] = fixed_name
                Global.transformation[fixed_name] = node.getPosition()
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('i', '[Makeprintable] Exporting nodes failed')
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in UploadNodes.py'.format(str(e), line))
            raise e
        finally:
            Logger.log('i', '[Makeprintable] Now exporting finished')
            Logger.log('i', '[Makeprintable] Number of node exported: ' + str(len(filenames)))
            return filenames

    def get_access_token(self):

        Logger.log('i', '[Makeprintable] Now getting access token started')
        access_token = Global.access_token
        Logger.log('i', '[Makeprintable] Now getting access token finished')
        Logger.log('i', '[Makeprintable] Access token: ' + access_token)
        return access_token

    def upload_files(self, filenames, access_token):
        success = None
        try:
            requesthandler = RequestHandler()
            requesthandler.progress.connect(self._send_progress)
            if len(filenames) > 0:
                thread = MPThread(requesthandler.upload_files, args=(access_token, filenames))
                thread.start()
                thread.join()
                success = thread.get_result()
            Logger.log('i', '[Makeprintable] Number of uploaded files: ' + str(len(success)))
            Logger.log('i', '[Makeprintable] Number of files not uploaded: ' + str(len(filenames) - len(success)))
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in UploadNodes.py'.format(str(e), line))
            raise e
        return success

    def process(self):
        success = {}
        try:
            # filenames = self.export_all_files()
            filenames = []
            for node in self._nodes:
                filename = node.getMeshData().getFileName()
                basename = os.path.splitext(os.path.basename(filename))[0]
                basename = Global.get_valid_string(basename)
                fixed_name = "{}/{}_fixed.obj".format(self._tempdir, basename)
                Global.fixed_filenames[node] = fixed_name
                Global.transformation[fixed_name] = node.getPosition()
                filenames.append(filename)
            access_token = self.get_access_token()
            success = self.upload_files(filenames, access_token)
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in UploadNodes.py'.format(str(e), line))
            raise e
        finally:
            for node in self._nodes:
                filename = node.getMeshData().getFileName()
                base = os.path.splitext(os.path.basename(filename))[0]
                base = Global.get_valid_string(base)
                if base not in success:
                    Global.fixed[node] = False
                    Global.failed_reason[node] = "Could not upload model."
                else:
                    Global.file_item_id[filename] = success[base]
            self._success = len(success)

    def get_len_success(self):
        return self._success

    def _emit_progress(self, progress):
        self._progress += progress
        self.progress.emit(self._progress)
        self._progress = 0
        # new_time = time.monotonic()
        # if not self._progress_emit_time or new_time - self._progress_emit_time > 0.5:
        #     self.progress.emit(self._progress)
        #     self._progress_emit_time = new_time
        #     self._progress = 0

    def _send_progress(self, iterations):
        self._emit_progress(iterations)

    def undo(self):
        pass

    def redo(self):
        pass

    def mergeWith(self, other):
        if type(other) is not UploadNodes:
            return False
        if other._nodes != self._nodes:
            return False
        op = UploadNodes(self._nodes)
        return op

    def __repr__(self):
        return "UploadNodes(nodes = {0})".format(self._nodes)


class MPThread(threading.Thread):
    def __init__(self, func, args=()):
        threading.Thread.__init__(self)
        self._func = func
        self._args = args
        self._result = None

    def run(self):
        self._result = self._func(self._args[0], self._args[1])

    def get_result(self):
        return self._result

    def stop(self):
        self._stop().set()
