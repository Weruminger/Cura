from .RequestHandler import RequestHandler
from . import Global
import http.server
import urllib.parse as urlparse
import os
import json
import tempfile
import mimetypes


class HTTPReqHandler(http.server.BaseHTTPRequestHandler):
    def __init__(self, request, client_address, server):
        self.dir_path = os.path.dirname(os.path.realpath(__file__))
        super().__init__(request, client_address, server)

    def _set_headers(self, code=None, content_type=None):
        if content_type is None:
            content_type = 'text/html'
        if code is None:
            code = 200
        self.send_response(code)
        self.send_header('Content-type', content_type)
        self.end_headers()

    def do_GET(self):
        www = '{}/www'.format(self.dir_path)
        request = RequestHandler()
        path = str(self.path)
        tempdir = tempfile.gettempdir()
        parsed_path = urlparse.parse_qs(urlparse.urlparse(path).query)
        auth_code = None
        try:
            auth_code = parsed_path['code'][0]
            access_token, refresh_token = request.get_access_token(auth_code, 'http://127.0.0.1:13277')
            data = {
                'access_token': access_token,
                'refresh_token': refresh_token
            }
            with open('{}/CuraAuthResponse.json'.format(Global.homeDir), 'w') as file:
                json.dump(data, file)
        except:
            if 'error' in parsed_path:
                self._set_headers(200)
                with open('{}/access_denied.html'.format(www), 'rb') as file:
                    self.wfile.write(file.read())
            else:
                path = '{}/{}'.format(www, self.path.split('?')[0])
                mimetype, _ = mimetypes.guess_type(path)
                if os.path.exists(path):
                    with open(path, 'rb') as file:
                        other = file.read()
                        self._set_headers(200, mimetype)
                        self.wfile.write(other)
                else:
                    self._set_headers(404)
            return

        self._set_headers(200)
        with open('{}/index.html'.format(www), 'rb') as file:
            self.wfile.write(file.read())
