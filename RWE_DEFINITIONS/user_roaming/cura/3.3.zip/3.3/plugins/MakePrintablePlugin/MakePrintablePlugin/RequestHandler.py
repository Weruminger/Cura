from UM.Operations.Operation import Operation
from UM.Signal import Signal
from UM.Logger import Logger
from PyQt5.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkReply
from PyQt5.QtCore import QUrl, QEventLoop
from . import Global
import http
import http.client as client
import urllib.request as request
import urllib.parse as urlparse
import shutil
import json
import time
import ssl
import sys


class RequestHandler(Operation):
    def __init__(self):
        super().__init__()
        self._url = Global.url
        self._client_id = 'PRDmYIUv0yrSGFgz6ulX'
        self._client_secret = 'HdRNMpILgUJY0OZG2AcE'
        self.progress = Signal()
        self._progress_emit_time = None
        self._progress = 0
        self._manager = None
        self._prev_bytes_sent = 0

    def _init_manager(self):
        try:
            self._manager = QNetworkAccessManager()
            self._prev_bytes_sent = 0
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in RequestHandler.py'.format(str(e), line))
            raise e

    def _upload_progress(self, bytes_sent, bytes_total):
        if bytes_total > 0:
            amount = 90 * (bytes_sent - self._prev_bytes_sent) / bytes_total
            self._emit_progress(amount)
            self._prev_bytes_sent = bytes_sent

    def qt_request(self, method, url, files=None, body=None, headers=None,
                   progress_callback=None):
        try:
            self._init_manager()
            net_request = QNetworkRequest(QUrl(url))
            payload_obj = Payload()
            loop = QEventLoop()
            reply = None
            if headers is None:
                headers = {}
            headers["content-type"] = "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW"
            if files is not None:
                for key, value in files.items():
                    payload_obj.add_files_to_payload(key, value)
            if body is not None:
                for key, value in body.items():
                    payload_obj.add_to_payload(key, value)
            for key, value in headers.items():
                net_request.setRawHeader(bytes(key, "utf-8"), bytes(value, "utf-8"))
            if method == "POST":
                reply = self._manager.post(net_request, payload_obj.get_pay_load())
            elif method == "GET":
                reply = self._manager.get(net_request)
            if progress_callback is not None:
                reply.uploadProgress.connect(progress_callback)
            reply.finished.connect(loop.quit)
            loop.exec_()
            if reply.error() != QNetworkReply.NoError:
                raise Exception(reply.errorString())
            return json.loads(bytes(reply.readAll()).decode("utf-8"))
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in RequestHandler.py'.format(str(e), line))
            raise e

    @staticmethod
    def request(method, url, files=None, payload=None, headers=None):
        try:
            url_parsed = urlparse.urlparse(url)
            if headers is None:
                headers = {}
            headers["content-type"] = "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW"
            context = ssl.SSLContext(protocol=ssl.PROTOCOL_SSLv23)
            context.load_default_certs(purpose=ssl.Purpose.SERVER_AUTH)
            payload_obj = Payload()
            if files is not None:
                for key, value in files.items():
                    payload_obj.add_files_to_payload(key, value)
            if payload is not None:
                for key, value in payload.items():
                    payload_obj.add_to_payload(key, value)
            conn = None
            if str.lower(url_parsed[0]) == 'https':
                conn = client.HTTPSConnection(url_parsed[1], context=context)
            else:
                conn = client.HTTPConnection(url_parsed[1])
            conn.request(method, url_parsed[2], payload_obj.get_pay_load(), headers)
            response = conn.getresponse()
            code = response.getcode()
            js_response = response.read().decode('utf-8')
            js = json.loads(js_response)
            return code, js
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in RequestHandler.py'.format(str(e), line))
            raise e

    @staticmethod
    def download(link, file_path):
        try:
            context = ssl.SSLContext(protocol=ssl.PROTOCOL_SSLv23)
            context.load_default_certs(purpose=ssl.Purpose.SERVER_AUTH)
            with request.urlopen(link, context=context) as response, open(file_path, 'wb+') as out_file:
                shutil.copyfileobj(response, out_file)
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in RequestHandler.py'.format(str(e), line))
            raise e

    def get_access_token(self, auth_code=None, back_url=None, refresh_token=None):
        try:
            body = None
            if auth_code is not None:
                body = {
                    'grant_type': 'authorization_code',
                    'code': auth_code,
                    'client_id': self._client_id,
                    'client_secret': self._client_secret,
                    'redirect_uri': back_url
                }
            elif refresh_token is not None:
                body = {
                    'grant_type': 'refresh_token',
                    'refresh_token': refresh_token,
                    'client_id': self._client_id,
                    'client_secret': self._client_secret,
                    'redirect_uri': back_url
                }
            else:
                body = {
                    'grant_type': 'client_credentials',
                    'client_id': self._client_id,
                    'client_secret': self._client_secret
                }
            code, js = RequestHandler.request('POST', 'https://{}/oauth2/token'.format(self._url), payload=body)
            if code in (http.HTTPStatus.BAD_GATEWAY, http.HTTPStatus.UNAUTHORIZED, http.HTTPStatus.BAD_REQUEST, http.HTTPStatus.NOT_FOUND):
                return None, None
            if auth_code is not None:
                return js['access_token'], js['refresh_token']
            return js['access_token'], None
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in RequestHandler.py'.format(str(e), line))
            raise e

    def upload_files(self, access_token, file_paths):
        try:
            all_files = []
            for file_path in file_paths:
                all_files.append(open(file_path, "rb"))
            headers = {
                "Authorization": "Bearer %s" % access_token
            }
            files = {
                "files[]": all_files
            }
            js = self.qt_request("POST", url="https://%s/v3/operation/upload" % self._url, files=files,
                            headers=headers, progress_callback=self._upload_progress)
            if type(js) is not list and js['status'] == http.HTTPStatus.UNAUTHORIZED:
                access_token, refresh_token = self.get_access_token(refresh_token=Global.refresh_token,
                                                                    back_url='http://127.0.0.1')
                Global.access_token = access_token
                with open(Global.homeDir + '/CuraAuthResponse.json', 'w') as file:
                    tmp = {
                        'access_token': access_token,
                        'refresh_token': Global.refresh_token
                    }
                    json.dump(tmp, file)
                return self.upload_files(access_token, file_paths)
            success = {}
            for part in js:
                if part['status'] in (http.HTTPStatus.OK, http.HTTPStatus.ACCEPTED):
                    out = part['operation']['output_name']
                    _id = part['operation']['_id']
                    success[out] = _id
            return success
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in RequestHandler.py'.format(str(e), line))
            raise e

    def get_progress(self, access_token, item_id):
        try:
            headers = {
                "Authorization": "Bearer %s" % access_token
            }
            code, js = RequestHandler.request("GET", "https://{}/v3/operation/{}".format(self._url, item_id), headers=headers)
            if js['status'] == http.HTTPStatus.UNAUTHORIZED:
                access_token, refresh_token = self.get_access_token(refresh_token=Global.refresh_token,
                                                     back_url='http://127.0.0.1')
                Global.access_token = access_token
                with open(Global.homeDir + '/CuraAuthResponse.json', 'w') as file:
                    tmp = {
                        'access_token': access_token,
                        'refresh_token': Global.refresh_token
                    }
                    json.dump(tmp, file)
                return self.get_progress(access_token, item_id)
            progress = js['operation']['progress']
            if js['operation']['status'] == 2:
                progress = 'Failed'
            return progress
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in RequestHandler.py'.format(str(e), line))
            raise e

    def get_download_link(self, access_token, item_id):
        try:
            headers = {
                "Authorization": "Bearer %s" % access_token
            }
            code, js = RequestHandler.request("GET", "https://{}/v3/operation/{}".format(self._url, item_id), headers=headers)
            if js['status'] == http.HTTPStatus.UNAUTHORIZED:
                access_token, refresh_token = self.get_access_token(refresh_token=Global.refresh_token,
                                                     back_url='http://127.0.0.1')
                Global.access_token = access_token
                with open(Global.homeDir + '/CuraAuthResponse.json', 'w') as file:
                    tmp = {
                        'access_token': access_token,
                        'refresh_token': Global.refresh_token
                    }
                    json.dump(tmp, file)
                return self.get_download_link(access_token, item_id)
            return js
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in RequestHandler.py'.format(str(e), line))
            raise e

    def fix(self, access_token, item_ids, fixer_settings=None, user_group=None):
        if user_group is None:
            user_group = "Free"
        if fixer_settings is None:
            fixer_settings = "{\"print_quality\": \"standard\",\"post_optimize\": 100,\"hollow\": 0,\"wall_thickness\":0,\"texture\":false, \"scale_x\":1, \"scale_y\":1, \"scale_z\":1,\"transform_x\":0,\"transform_y\":0,\"transform_z\":0,\"rotate_x\":0,\"rotate_y\":0,\"rotate_z\":0,\"clearance\": 0, \"closing_threshold\": 0}"
            # if user_group == "Free":
            #     fixer_settings = "{\"print_quality\": \"standard\", \"post_optimize\": 45, \"hollow\": 0, \"wall_thickness\": 1, \"texture\": false, \"scale_x\": 1, \"scale_y\": 1, \"scale_z\": 1, \"transform_x\": 0, \"transform_y\": 0, \"transform_z\": 0, \"rotate_x\": 0, \"rotate_y\": 0, \"rotate_z\": 0}"
            # else:
            #     pass
        Logger.log("i", "[MakePrintable] fixer settings: %s" % fixer_settings)
        try:
            headers = {
                "Authorization": "Bearer %s" % access_token
            }

            inputs = '['
            for item_id in item_ids:
                inputs += '{"operation_id":"' + item_id + '"},'
            inputs = inputs[0:len(inputs)-1]
            inputs += ']'

            payload = {
                'inputs': inputs,
                'operation_settings': fixer_settings
            }

            url = "/v3/operation/mammoth"
            # if user_group == "Free":
            #     url = "/v3/operation/fix"
            code, js = RequestHandler.request('POST', 'https://{}{}'.format(self._url, url), payload=payload, headers=headers)
            success = {}
            failed = {}
            new_ids = []
            if type(js) is not list and js['status'] == http.HTTPStatus.UNAUTHORIZED:
                access_token, refresh_token = self.get_access_token(refresh_token=Global.refresh_token,
                                                     back_url='http://127.0.0.1')
                Global.access_token = access_token
                with open(Global.homeDir + '/CuraAuthResponse.json', 'w') as file:
                    tmp = {
                        'access_token': access_token,
                        'refresh_token': Global.refresh_token
                    }
                    json.dump(tmp, file)
                return self.fix(access_token, item_ids, fixer_settings)
            try:
                for part in js:
                    status = part['status']
                    if status in (http.HTTPStatus.OK, http.HTTPStatus.ACCEPTED):
                        new_ids.append(part['operation']['_id'])
                    # else:
                    #     filename = part['operation']['output_name']
                    #     failed[filename] = part['message']
            except Exception as e:
                line = sys.exc_info()[2].tb_lineno
                Logger.log('e', '[Makeprintable] Exception: {} line: {} in RequestHandler.py'.format(str(e), line))
                raise e

            check_progress = list(new_ids)
            all_progress = dict((new_id, 0) for new_id in new_ids)

            while True:
                for new_id in check_progress:
                    progress = self.get_progress(access_token, new_id)
                    if progress != 'Failed':
                        self._emit_progress((progress - all_progress[new_id]) / len(Global.fixed))
                    all_progress[new_id] = progress
                    if progress == 'Failed' or progress == 100:
                        check_progress.remove(new_id)
                if len(check_progress) == 0:
                    break
                time.sleep(5)

            for new_id in new_ids:
                res = self.get_download_link(access_token, new_id)
                download_link = None
                try:
                    download_link = res['outputs'][0]['output']
                except:
                    pass
                filename = res['operation']['output_name']
                if all_progress[new_id] == 100:
                    Logger.log("i", "[Makeprintable] %s if fully fixed" % filename)
                    success[filename] = download_link
                else:
                    Logger.log("i", "[Makeprintable] %s has failed to fix" % filename)
                    failed[filename] = res['message']
            return success, failed
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in RequestHandler.py'.format(str(e), line))
            raise e

    def _emit_progress(self, progress):
        self._progress += progress
        self.progress.emit(self._progress)
        self._progress = 0
        # new_time = time.monotonic()
        # if not self._progress_emit_time or new_time - self._progress_emit_time > 0.5:
        #     self.progress.emit(self._progress)
        #     self._progress_emit_time = new_time
        #     self._progress = 0

    def undo(self):
        pass

    def redo(self):
        pass

    def mergeWith(self, other):
        if type(other) is not RequestHandler:
            return False

        op = RequestHandler()
        return op

    def __repr__(self):
        return "RequestHandler(nodes = 0)"


class Payload:
    def __init__(self):
        self._payload = None

    def add_to_payload(self, field_name, field_value):
        if type(field_value) is list:
            for val in field_value:
                self.add_to_payload(field_name, val)
            return
        if self._payload is None:
            if type(field_value) is bytes:
                self._payload = bytes(
                    '------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"' + field_name + '\"\r\n\r\n',
                    'utf-8') + field_value + bytes('\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--', 'utf-8')
            else:
                self._payload = bytes(
                    '------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"' + field_name + '\"\r\n\r\n' + field_value + '\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--',
                    'utf-8')
        else:
            self._payload = self._payload[0:len(self._payload) - 2]
            if type(field_value) is bytes:
                self._payload = self._payload + bytes('\r\nContent-Disposition: form-data; name=\"' + field_name + '\"\r\n\r\n', 'utf-8') + field_value + bytes('\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--', 'utf-8')
            else:
                self._payload = self._payload + bytes('\r\nContent-Disposition: form-data; name=\"' + field_name + '\"\r\n\r\n' + field_value + '\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--', 'utf-8')

    def add_files_to_payload(self, field_name, files):
        if type(files) is list:
            for file in files:
                self.add_files_to_payload(field_name, file)
            return
        chunk = files.read()
        filename = files.name
        if self._payload is None:
            if type(chunk) is bytes:
                self._payload = bytes(
                    '------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"' + field_name + '\"; filename=\"' + filename + '\";\r\nContent-Type: application/octet-stream\r\n\r\n',
                    'utf-8') + chunk + bytes('\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--', 'utf-8')
            else:
                self._payload = bytes(
                    '------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"' + field_name + '\"; filename=\"' + filename + '\";\r\nContent-Type: application/octet-stream\r\n\r\n' + chunk + '\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--',
                    'utf-8')
        else:
            self._payload = self._payload[0:len(self._payload) - 2]
            if type(chunk) is bytes:
                self._payload = self._payload + bytes('\r\nContent-Disposition: form-data; name=\"' + field_name + '\"; filename=\"' + filename + '\";\r\nContent-Type: application/octet-stream\r\n\r\n', 'utf-8') + chunk + bytes('\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--', 'utf-8')
            else:
                self._payload = self._payload + bytes('\r\nContent-Disposition: form-data; name=\"' + field_name + '\"; filename=\"' + filename + '\";\r\nContent-Type: application/octet-stream\r\n\r\n' + chunk + '\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--', 'utf-8')

    def get_pay_load(self):
        return self._payload
