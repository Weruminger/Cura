from . import MakePrintableTool


def getMetaData():
    return {
        "tool": {
            "name": "Fix Model",
            "description": "Fix model in MakePrintable.com",
            "icon": "MP_logo.svg",
            "tool_panel": "Main.qml",
            "weight": 10
        }
    }


def register(app):
    return {"tool": MakePrintableTool.MakePrintableTool()}
