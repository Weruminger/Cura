from UM.Resources import Resources
homeDir = Resources.getStoragePath(Resources.Resources)
url = "api.makeprintable.com"


def init():
    global startedFixing
    global fixed_filenames
    global transformation
    global access_token
    global refresh_token
    global fixed
    global combined_filename
    global download_link
    global sslError
    global file_item_id
    global downloaded
    global auth_code
    global back_url
    global failed_reason
    global message
    global progress_bar
    global user_group
    startedFixing = False
    fixed_filenames = {}
    transformation = {}
    file_item_id = {}
    fixed = {}
    download_link = {}
    downloaded = {}
    failed_reason = {}
    access_token = None
    refresh_token = None
    sslError = False
    auth_code = None
    back_url = None
    message = None
    progress_bar = 0
    user_group = "Free"
    combined_filename = None


def get_valid_string(st):
    nst = ''
    for c in st:
        if not c.isalpha() and not c.isnumeric():
            nst += '_'
        else:
            nst += c
    return nst
