from .HTTPServer import HTTPReqHandler
from http.server import HTTPServer


def start(port=None):
    if port is None:
        port = 13277
    server = HTTPServer(('localhost', port), HTTPReqHandler)
    server.serve_forever()
