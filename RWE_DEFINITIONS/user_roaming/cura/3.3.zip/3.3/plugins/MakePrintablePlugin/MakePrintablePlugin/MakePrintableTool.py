from UM.Tool import Tool
from UM.Job import Job
from UM.Message import Message
try:
    from UM.Scene.SceneNode import SceneNode
except:
    pass
try:
    from cura.Scene.CuraSceneNode import CuraSceneNode
except:
    pass
from UM.Scene.Selection import Selection
from UM.Preferences import Preferences
from UM.Math.Vector import Vector
from UM.Operations.AddSceneNodeOperation import AddSceneNodeOperation
from UM.Operations.RemoveSceneNodeOperation import RemoveSceneNodeOperation
from UM.Operations.GroupedOperation import GroupedOperation
from UM.Operations.SetTransformOperation import SetTransformOperation
from UM.Application import Application
from UM.Mesh.MeshData import MeshData
from UM.Logger import Logger
from UM.Scene.Iterator.DepthFirstIterator import DepthFirstIterator
from PyQt5.QtGui import QDesktopServices
from PyQt5.QtCore import QUrl
try:
    from cura.Scene.BuildPlateDecorator import BuildPlateDecorator
    from cura.SliceableObjectDecorator import SliceableObjectDecorator
    from cura.ZOffsetDecorator import ZOffsetDecorator
    from cura.ConvexHullDecorator import ConvexHullDecorator
    from cura.PlatformPhysicsOperation import PlatformPhysicsOperation
except:
    pass

import tempfile
import json
import sys
import http
import os
import copy
import threading
import random
from . import Global, Server, RequestHandler
from .OverallOperation import OverallOperation

if not os.path.exists(Global.homeDir):
    os.makedirs(Global.homeDir)

Global.init()

def get_center(vertices):
    minx, maxx = 1e+9, 1e-9
    miny, maxy = 1e+9, 1e-9
    minz, maxz = 1e+9, 1e-9
    for vertex in vertices:
        minx = min(minx, vertex[0])
        miny = min(miny, vertex[1])
        minz = min(minz, vertex[2])

        maxx = max(maxx, vertex[0])
        maxy = max(maxy, vertex[1])
        maxz = max(maxz, vertex[2])
    midx, midy, midz = (maxx + minx) / 2, (maxy + miny) / 2, (maxz + minz) / 2
    return Vector(midx, midy, midz)


class MakePrintableTool(Tool):
    def __init__(self):
        super().__init__()
        self._progress_message = None
        self._iterations = 0
        self._total_iterations = 0
        self._selected = []
        self._tempdir = tempfile.gettempdir()
        self._tempdir.replace('\\', '/')
        self._model_quality = 0
        self._post_opt = 100
        self._clearance = 0
        self._thickness = 0
        self._close_holes = 0
        self.setExposedProperties("ModelQuality", "PostOpt", "Clearance", "Thickness", "CloseHoles")
        self._scene = Application.getInstance().getController().getScene()
        self._port = 13277
        self._url = "https://%s" % Global.url
        self._client_id = 'PRDmYIUv0yrSGFgz6ulX'
        self._redirect_url = 'http://localhost:{}'.format(self._port)
        self._to_delete = []
        self._copy_node = None
        self._state = random.getrandbits(32)
        self._update_other_progress_flag = True
        self._update_collecting_progress_flag = True
        self._auth_url = '{}/authorize?client_id={}&state={}&callback_url={}&response_type=code'.format(
            self._url,
            self._client_id,
            self._state,
            self._redirect_url
        )
        thread = threading.Thread(target=Server.start)
        thread.daemon = True
        thread.start()

    def get_nodes_size(self, selected_models):
        all_size = 0
        if type(selected_models) is list:
            for model in selected_models:
                filename = model.getMeshData().getFileName()
                all_size += os.path.getsize(filename)
        else:
            all_size = os.path.getsize(selected_models.getMeshData().getFileName())
        return all_size

    def combine_models(self, selected_models):
        writer = Application.getInstance().getMeshFileHandler().getWriter("STLWriter")
        reader = Application.getInstance().getMeshFileHandler().getReaderForFile("_.stl")
        file_name = self._tempdir + "/all_model.stl"
        with open(file_name, "wb") as stream:
            writer.write(stream, selected_models, mode=writer.OutputMode.BinaryMode)
        new_node = reader.read(file_name)
        return new_node
        # vertices = []
        # faces = []
        # face_offset = 0
        # for model in selected_models:
        #     mesh_data = model.getMeshDataTransformed()
        #     verts = mesh_data.getVertices()
        #     if mesh_data.hasIndices():
        #         for face in mesh_data.getIndices():
        #             vertices.extend([verts[face[0]], verts[face[1]], verts[face[2]]])
        #             faces.extend([face[0] + face_offset, face[1] + face_offset, face[2] + face_offset])
        #     else:
        #         for vertex in verts:
        #             vertices.extend([vertex[0], vertex[1], vertex[2]])
        #         for face in range(face_offset, face_offset + len(verts) - 1, 3):
        #             faces.extend([face, face + 1, face + 2])
        #     face_offset += mesh_data.getVertexCount()
        # scene_node = selected_models[0]
        # scene_node.getMeshData().set(vertices=vertices, indices=faces)
        # vert_length = scene_node.getMeshData().getVertexCount()
        # face_length = scene_node.getMeshData().getFaceCount()
        # return scene_node, vert_length, face_length

    def _open_makeprintable(self, message, action):
        if action == "open":
            QDesktopServices.openUrl(QUrl("https://makeprintable.com"))
    
    def _open_support(self, message, action):
        if action == "open":
            QDesktopServices.openUrl(QUrl("http://support.makeprintable.com"))

    def get_user_info(self, access_token):
        headers = {
            "Authorization": "Bearer {}".format(access_token)
        }
        code, js = RequestHandler.RequestHandler.request('GET', '%s/v3/user' % self._url, headers=headers)
        if 'status' in js and js['status'] in (http.HTTPStatus.UNAUTHORIZED, http.HTTPStatus.NOT_FOUND):
            req = RequestHandler.RequestHandler()
            access_token, refresh_token = req.get_access_token(back_url='http://127.0.0.1:{}'.format(self._port),
                                                               refresh_token=Global.refresh_token)
            if access_token is None and refresh_token is None:
                return None
            Logger.log('i', '[Makeprintable] Access_token: ' + access_token)
            Global.access_token = access_token
            with open('{}/CuraAuthResponse.json'.format(Global.homeDir), 'w') as file:
                data = {
                    'access_token': Global.access_token,
                    'refresh_token': Global.refresh_token
                }
                json.dump(data, file)
            return self.get_user_info(access_token)
        Logger.log('i', '[Makeprintable] User_info: ' + str(js))
        return js

    def fix_model(self):
        if Global.startedFixing is True:
            return
        if self._model_quality == 0:
            self.stopAndReset("Please choose a quality from the fixing menu.")
            Logger.log("i", "[Makeprintable] Did not choose a quality from the combobox. Fix is canceled.")
            return
        try:
            if Global.access_token is None:
                if os.path.exists('{}/CuraAuthResponse.json'.format(Global.homeDir)):
                    with open('{}/CuraAuthResponse.json'.format(Global.homeDir)) as file:
                        data = json.load(file)
                        if 'access_token' in data:
                            Global.access_token = data['access_token']
                            Global.refresh_token = data['refresh_token']
                else:
                    QDesktopServices.openUrl(QUrl(self._auth_url))
                    return
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in MakePrintableTool.py'.format(str(e), line))
            return

        try:
            thread = threading.Thread(target=self.process)
            thread.daemon = True
            thread.start()
            self._progress_message = Message('Collecting user info...', dismissable=False,
                                             lifetime=0, progress=-1)
            self._progress_message.show()
            self.operationStarted.emit(self)
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in MakePrintableTool.py'.format(str(e), line))
        
    def update_collecting_progress(self):
        if not self._update_collecting_progress_flag:
            return
        thread = threading.Timer(20, self.update_collecting_progress)
        thread.daemon = True
        thread.start()
        self._progress_message = Message('Collecting user info...', dismissable=False,
                                            lifetime=0, progress=-1)
        self._progress_message.show()

    def process(self):
        try:
            self._update_collecting_progress_flag = False
            user_info = self.get_user_info(Global.access_token)
            if user_info is None:
                QDesktopServices.openUrl(QUrl(self._auth_url))
                self.stopAndReset("Reauthorization is required")
                return
            user_group = user_info["user_group"]
            Global.user_group = user_group
            settings_changed = self._clearance != 0.5 or self._thickness != 0 or self._post_opt != 100 or self._model_quality != 1
            if user_group == "Free" and settings_changed:
                if self._progress_message:
                    self._progress_message.hide()
                    self._progress_message = None
                self._progress_message = Message("Non MakePrintable.com pro users can only fix with the following default settings:\n > Quality: Medium\n > Post Optimization: 100\n > Clearance: \t0.5\n > Thickness: \t0", lifetime=30, dismissable=True)
                self._progress_message.addAction("open", "Open", "[no_icon]", "[no_description]")
                self._progress_message.actionTriggered.connect(self._open_makeprintable)
                self._progress_message.show()
                self.stopAndReset()
                Logger.log('i', '[Makeprintable] Fixing stopped because a non pro user tried to change settings')
                return

            Global.startedFixing = True
            fixed = {}
            for selected in Selection.getAllSelectedObjects():
                self._to_delete.append(selected)
                # self._selected.append(selected)
                # fixed[selected] = True

            center = Selection.getSelectionCenter()
            node = self.combine_models(Selection.getAllSelectedObjects())
            memo = None
            self._copy_node = self._to_delete[0].__deepcopy__(memo)

            size = self.get_nodes_size(node)

            if size > 2e8:
                self.stopAndReset("Size of fix is more than 200 MB.")
                Logger.log("i", "Size of fix was more than 200 MB, fix was canceled")
                return

            node.setPosition(center, CuraSceneNode.TransformSpace.World)
            if self._progress_message is not None:
                self._progress_message.hide()
                self._progress_message = None

            self._selected.append(node)
            fixed[node] = True
            Global.fixed = fixed
            model = "model"
            if Selection.getCount() > 1:
                model = "models"
            Global.message = "Uploading to MakePrintable.com"
            self._progress_message = Message(Global.message, lifetime=0,
                                             dismissable=False, progress=0)
            self._progress_message.show()
            # if user_group == "Free":
            #     self._post_opt = 45
            #     self._thickness = 1
            operation = OverallOperation(self._selected, self._model_quality, self._post_opt,
                                         self._clearance, self._thickness, self._close_holes, user_group)
            operation.progress.connect(self._mp_progress)
            job = MPJob(operation)
            job.finished.connect(self._mp_finished)
            job.start()
            Logger.log('i', '[Makeprintable] Fixing process started')
        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in MakePrintableTool.py'.format(str(e), line))
    
    def update_upload_progress(self):
        if not Global.message.startswith("Uploading"):
            return
        thread = threading.Timer(20, self.update_upload_progress)
        thread.daemon = True
        thread.start()
        Global.progress_bar += 1
        self._mp_progress(1)

    def update_other_progress(self):
        self._update_other_progress_flag = False
        if Global.message is None or Global.message.startswith("Finished"):
            return
        thread = threading.Timer(20, self.update_other_progress)
        thread.daemon = True
        thread.start()
        self._mp_progress(1)

    def _mp_progress(self, iterations):
        # self._iterations += iterations
        if self._progress_message:
            self._progress_message.hide()
            self._progress_message = None
        if Global.message.startswith("Uploading") and 90 >= Global.progress_bar >= 89:
            self.update_upload_progress()
            return
        if not Global.message.startswith("Uploading") and self._update_other_progress_flag:
            self.update_other_progress()
            return
        progress = min([Global.progress_bar, 97])
        self._progress_message = Message(Global.message, progress=progress,
                                         dismissable=False, lifetime=0)
        self._progress_message.show()

    def _mp_finished(self, job):
        if self._progress_message:
            self._progress_message.hide()
            self._progress_message = None

        if sum(Global.fixed.values()) == 0:
            reason = "You have maxed out your balance or fix failed"
            unfixed_models = ""
            for selected in self._to_delete:
                unfixed_models += "> {} ====> not fixed: {}\n".format(selected.getName(), reason)
            self._progress_message = Message("Something went wrong:\n{}\nNavigate to makeprintable.com for more info.".format(unfixed_models), lifetime=30, dismissable=True)
            self._progress_message.addAction("open", "Open", "[no_icon]", "[no_description]")
            self._progress_message.actionTriggered.connect(self._open_makeprintable)
            self._progress_message.show()
            self.stopAndReset()
            Logger.log('i', '[Makeprintable] Failed to fix models in makeprintable.com.')
            Logger.log('i', '[Makeprintable] Unfixed models reason: ' + unfixed_models)
            return

        Logger.log('i', '[Makeprintable] All fixing processes finished successfully.')
        self._progress_message = Message("Replacing models in scene...", dismissable=False,
                                         lifetime=0, progress=-1)
        self._progress_message.show()
        obj_read = Application.getInstance().getMeshFileHandler().getReaderForFile("_.obj")
        scene_nodes = []
        fixed_list = Global.fixed_filenames
        message = ""
        fixed_models = ""
        unfixed_models = ""

        try:
            for selected in self._to_delete:
                # fixed = Global.fixed[selected]
                model_name = selected.getName()
                if model_name in (None, ""):
                    model_name = os.path.splitext(os.path.basename(selected.getMeshData().getFileName()))[0]
                # if not fixed:
                #     unfixed_models += "> {} ====> not fixed: {}\n".format(model_name, Global.failed_reason[selected])
                # else:
                fixed_models += "> {} ====> fixed".format(model_name)

            message = "Status:\n" + fixed_models + unfixed_models

            for node, filename in fixed_list.items():
                if Global.fixed[node]:
                    sn = obj_read.read(filename)
                    sn.setSelectable(True)
                    center = get_center(sn.getMeshData().getVertices())
                    sn.setCenterPosition(center)
                    scene_nodes.append(sn)

            try:
                op = GroupedOperation()
                for idx, val in enumerate(self._to_delete):
                    op.addOperation(RemoveSceneNodeOperation(self._to_delete[idx]))
                op.push()

                """
                if len(self._to_delete) > 0:
                    self._to_delete[0].setMeshData(scene_nodes[0].getMeshData())
                    self._to_delete[0].setSelectable(True)
                else:
                    # self._copy_node.setMeshData(scene_nodes[0].getMeshData())
                    self._copy_node = scene_nodes[0]
                    self._copy_node.setSelectable(True)
                    self._copy_node.addDecorator(ZOffsetDecorator())
                    self._copy_node.addDecorator(ConvexHullDecorator())
                    self._copy_node.addDecorator(SliceableObjectDecorator())
                """
            except:
                pass

            """
            for node, filename in fixed_list.items():
                if Global.fixed[node]:
                    sn = obj_read.read(filename)
                    sn.setSelectable(True)
                    center = get_center(sn.getMeshData().getVertices())
                    sn.setCenterPosition(center)
                    scene_nodes.append(sn)
            """

            #if len(self._to_delete) <= 0:
            op = GroupedOperation()
            op.addOperation(AddSceneNodeOperation(scene_nodes[0], self._scene.getRoot()))
            op.push()
            
            Application.getInstance().getController().getScene().sceneChanged.emit(scene_nodes[0])

        except Exception as e:
            line = sys.exc_info()[2].tb_lineno
            Logger.log('e', '[Makeprintable] Exception: {} line: {} in MakePrintableTool.py'.format(str(e), line))
            message = "Something went wrong, your fixing process could not be finished"
        Logger.log('i', '[Makeprintable] Final report: ' + message)
        if self._progress_message:
            self._progress_message.hide()
            self._progress_message = None
        self._progress_message = Message(message + "\n{}".format(unfixed_models), lifetime=30, dismissable=True)
        self._progress_message.addAction("open", "Need help?", "[no_icon]", "[no_description]")
        self._progress_message.actionTriggered.connect(self._open_support)
        self._progress_message.show()
        self.stopAndReset()

    def setModelQuality(self, index):
        if self._model_quality != index:
            self._model_quality = index
            self.propertyChanged.emit()

    def setPostOpt(self, value):
        if self._post_opt != value:
            self._post_opt = value
            self.propertyChanged.emit()

    def setClearance(self, value):
        if self._clearance != value:
            self._clearance = value
            self.propertyChanged.emit()

    def setThickness(self, value):
        if self._thickness != value:
            self._thickness = value
            self.propertyChanged.emit()
    
    def setCloseHoles(self, value):
        if self._close_holes != value:
            self._close_holes = value
            self.propertyChanged.emit()

    def getModelQuality(self):
        return self._model_quality

    def getPostOpt(self):
        return self._post_opt

    def getClearance(self):
        return self._clearance

    def getThickness(self):
        return self._thickness

    def getCloseHoles(self):
        return self._close_holes

    def _getProgress(self):
        return 100 * self._iterations / self._total_iterations

    def stopAndReset(self, e=None):
        if e is not None:
            if self._progress_message:
                self._progress_message.hide()
                self._progress_message = None
            self._progress_message = Message(e, lifetime=30, dismissable=True)
            self._progress_message.show()
        Global.init()
        self._selected.clear()
        self._to_delete.clear()
        self.operationStopped.emit(self)


class MPJob(Job):
    def __init__(self, operations):
        super().__init__()
        self._operations = operations

    def run(self):
        self._operations.process()
